﻿using System;
namespace MySpectrumTest
{
    public class PersonModel
    {
        public int ID { get; set; }
        public string UserName { get; set; }
        public string EmailID { get; set; }
    }
}
